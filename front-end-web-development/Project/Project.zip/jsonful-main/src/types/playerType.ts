export interface playerType {
	id: number
	name: string
	team: string
	role: string
	score: number
	img: string
}
