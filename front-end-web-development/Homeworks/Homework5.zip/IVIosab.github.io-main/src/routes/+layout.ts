export const prerender = true;
export const trailingSlash = 'always';
