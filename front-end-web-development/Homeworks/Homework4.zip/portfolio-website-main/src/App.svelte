<script lang="ts">
  import Header from "./lib/Header.svelte";
  import Footer from "./lib/Footer.svelte";
  import About from "./lib/About.svelte";
  import Projects from "./lib/Projects.svelte";
  import Comic from "./lib/Comic.svelte";
</script>

<Header />
<main>
  <About />
  <Projects />
  <Comic />
</main>
<Footer />
