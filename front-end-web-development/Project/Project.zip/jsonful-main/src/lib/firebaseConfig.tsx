// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app"
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
	apiKey: "AIzaSyCJ4q82yFOqg_dcpTIy5IdycNw5jKJupgI",
	authDomain: "jsonful-f40c7.firebaseapp.com",
	projectId: "jsonful-f40c7",
	storageBucket: "jsonful-f40c7.appspot.com",
	messagingSenderId: "275278738974",
	appId: "1:275278738974:web:39f7e45e25298aa64aa00f",
}

// Initialize Firebase
export const app = initializeApp(firebaseConfig)
