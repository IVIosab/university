export interface compType {
	top_id: number
	mid_id: number
	jg_id: number
	adc_id: number
	supp_id: number
	coach_id: number
	comp_id: string
	owner_id: string
	owner_name: string
}
