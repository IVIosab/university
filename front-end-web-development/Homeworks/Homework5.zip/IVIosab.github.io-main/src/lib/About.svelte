<script lang="ts">
	import sleepingMosab from '$lib/images/sleepingMosab.png';
</script>

<div id="about">
	<img src={sleepingMosab} alt="my beautiful self" />
	<article>
		<h2>About Me</h2>
		<p>I am a 3rd year Computer Science student in Innopolis University.</p>
		<p>I started coding when I was 12 years old but I am still bad at it.</p>
		<p>I like various kinds of technologies, but I am yet to specialize in any of them.</p>
	</article>
</div>

<style>
	div {
		display: flex;
		align-items: center;
		justify-content: space-evenly;
	}
	article {
		text-align: center;
	}
	h2 {
		font-size: 1.5rem;
		text-align: center;
	}
	img {
		border-radius: 50%;
		width: 20%;
		height: auto;
		padding-top: 20px;
	}
</style>
