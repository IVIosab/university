<script lang="ts">
	import Comic from '../../lib/Comic.svelte';
</script>

<Comic />
