export interface coachType {
	id: number
	name: string
	team: string
	score: number
	img: string
}
