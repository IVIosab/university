<script lang="ts">
	import Projects from '$lib/Projects.svelte';
</script>

<Projects />
