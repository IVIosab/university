<script lang="ts">
</script>

<header>
  <h1>Mosab "IVIosab" Mohamed</h1>
  <nav>
    <ul>
      <li><a href="#about">About</a></li>
      <li><a href="#projects">Projects</a></li>
      <li><a href="#contacts">Contacts</a></li>
    </ul>
  </nav>
</header>

<style>
  header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem;
    background-color: #333;
    color: #fff;
  }
  nav ul {
    display: flex;
    list-style: none;
  }

  nav ul li {
    margin: 0 1rem;
  }

  nav a {
    color: #fff;
  }

  a {
    text-decoration: none;
    color: black;
  }

  h1 {
    padding-left: 10px;
  }
</style>
