<script lang="ts">
	import About from '../../lib/About.svelte';
</script>

<About />
